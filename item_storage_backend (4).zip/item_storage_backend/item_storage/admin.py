from django.contrib import admin

# Register your models here.
from .models import Item


class ItemsAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "price", "created_at"]
    search_fields = ["name"]


admin.site.register(Item, ItemsAdmin)
