from django.urls import path

from item_storage import views

urlpatterns = [
    path("items/v1/", views.get_all_items),
]