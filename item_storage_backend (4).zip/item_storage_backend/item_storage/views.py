from django.shortcuts import render
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator
from django.http import HttpResponse


@require_http_methods(['GET'])
def get_all_items(request):
    from item_storage.models import Item

    sort_by=request.GET.get('sort_by','name')
    order=request.GET.get('order','asc')
    page_number = request.GET.get('page', 1)

    valid_sort_by_values = ["name","price","created_at"]
    valid_order_by_values=["asc","desc"]
    if sort_by not in valid_sort_by_values:
        return HttpResponse("Invalid sort by Parameter value",status=400)
    if order not in valid_order_by_values:
        return HttpResponse("Invalid order by Parameter value",status=400)
    try:
        int(page_number)
    except Exception:
        return HttpResponse("Page number must be an integer",status=400)

    if order == 'desc':
        sort_by_field = f'-{sort_by}'
        next_order = 'asc'
    else:
        sort_by_field = sort_by
        next_order = 'desc'

    items=Item.objects.all().order_by(sort_by_field)

    page_number = request.GET.get('page', 1)
    paginator = Paginator(items, 2)
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'sort_by': sort_by,
        'order': order,
        'next_order': next_order
    }

    return render(
        request,'item_template.html', context)
